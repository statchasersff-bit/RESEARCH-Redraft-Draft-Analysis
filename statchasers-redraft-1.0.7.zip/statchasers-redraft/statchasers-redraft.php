<?php
/**
 * Plugin Name: StatChasers Redraft Analyzer
 * Plugin URI:  https://statchasers.com
 * Description: Embed the StatChasers fantasy football redraft strategy analyzer on any WordPress page. Use the shortcode [statchasers_redraft] on any page or post.
 * Version:     1.0.7
 * Author:      StatChasers
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function statchasers_redraft_assets_url() {
    return trailingslashit( plugin_dir_url( __FILE__ ) . 'assets' );
}

function statchasers_redraft_shortcode( $atts ) {
    static $rendered = false;
    $assets_url  = statchasers_redraft_assets_url();
    $assets_path = plugin_dir_path( __FILE__ ) . 'assets/';

    $html = '';

    if ( ! $rendered ) {
        // Load Inter from Google Fonts — the app's font stack relies on it.
        // Use wp_enqueue_style so WordPress deduplicates it if already loaded.
        wp_enqueue_style(
            'statchasers-inter-font',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
            [],
            null
        );

        // Inline the full scoped CSS once per page load.
        // Inline <style> tags inside shortcode output are never processed by
        // WordPress caching/minification plugins, so @layer rules and CSS
        // custom properties are guaranteed to reach the browser intact.
        $css_file = $assets_path . 'index.css';
        if ( file_exists( $css_file ) ) {
            $html .= '<style id="statchasers-redraft-styles">' . file_get_contents( $css_file ) . '</style>' . "\n";
        }
        $rendered = true;
    }

    // Enqueue the JS module in the footer.
    wp_enqueue_script(
        'statchasers-redraft-script',
        $assets_url . 'index.js',
        [],
        '1.0.7',
        true
    );
    wp_add_inline_script(
        'statchasers-redraft-script',
        'window.__SC_BASE_URL__ = ' . wp_json_encode( $assets_url ) . ';',
        'before'
    );

    $html .= '<div class="sc-draft-analysis-fullbleed"><div class="sc-draft-analysis-app"><div id="statchasers-redraft-root" style="min-height:600px;width:100%;"></div></div></div>';
    return $html;
}
add_shortcode( 'statchasers_redraft', 'statchasers_redraft_shortcode' );

add_filter( 'script_loader_tag', function( $tag, $handle, $src ) {
    if ( 'statchasers-redraft-script' === $handle ) {
        return '<script type="module" src="' . esc_url( $src ) . '"></script>' . "\n";
    }
    return $tag;
}, 10, 3 );
